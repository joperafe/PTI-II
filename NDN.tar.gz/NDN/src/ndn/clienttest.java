/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ndn;

/**
 *
 * @author andre
 */
import java.io.*;
import java.net.*;

import java.io.*;
import java.net.*;
import java.util.Enumeration;

class clienttest
{
   public static void main(String args[]) throws Exception
   {
      //BufferedReader inFromUser =
         //new BufferedReader(new InputStreamReader(System.in));
       
      Enumeration<NetworkInterface> ifs = NetworkInterface.getNetworkInterfaces();
         //while (ifs.hasMoreElements()) {
            NetworkInterface ni = ifs.nextElement();
            //ignoringg loopback, inactive interfaces and the interfaces that do not support multicast
            
            Enumeration<InetAddress> addrs = ni.getInetAddresses();//devolve os INETaddresses associado a eth
            
               InetAddress IPAddress2 = addrs.nextElement();
               //including addresses of the same type of group address
               //if (group.getClass() != addr.getClass()) continue;
               //if ((group.isMCLinkLocal() && addr.isLinkLocalAddress())
                  //|| (!group.isMCLinkLocal() && !addr.isLinkLocalAddress())) {
                  //System.out.println("Interface: " + ni.getDisplayName() + " Address: " +addr);
                  //result.add(addr);
               //} else {
                  //System.out.println("Ignoring addr: " + addr + " of interface "
 //+ ni.getDisplayName());
            //   }
       
      InetAddress IPAddress = InetAddress.getByName("FF02::1");
      //InetAddress IPAddress2 = InetAddress.getByName("fe80::200:ff:feaa:0");
      System.out.println("#" + IPAddress2);
      DatagramSocket clientSocket = new DatagramSocket(9877, IPAddress2);
      System.out.println("#" + IPAddress2 + "PORT" + clientSocket.getPort());
      byte[] sendData = new byte[1024];
      byte[] receiveData = new byte[1024];
      String sentence = "mensagem de teste";
      sendData = sentence.getBytes();      
      DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
      clientSocket.send(sendPacket);
      System.out.println("enviou a 1 msg ag receber");
      DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
      clientSocket.receive(receivePacket);
      String modifiedSentence = new String(receivePacket.getData());
      System.out.println("FROM SERVER:" + modifiedSentence);
      clientSocket.close();
   }
}
